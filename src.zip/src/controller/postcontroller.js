import { json } from "express";
import {getTodosPosts, criarpost, altulizarpost} from "../models/postsmodelos.js";
import fs from "fs";
import gerarDescricaoComGeminif from "../service/servicei.js";

export async function uploadimagem(req, res) {
    const novopost = {
        descrisao: "",
        imgUrl: req.file.orignalname,
        alt: ""
    };
}


export async function listarposts (req, res) {
    const posts = await getTodosPosts();
    res.status(200).json(posts);
    }



export async function postarnovopost(req, res){
    const novopost = req.body;
    try{
        const postcriado = await criarpost(novopost);
        const imagematualizada = `uploads/${postcriado.insertedId}.gif`
        fs.renameSync(req.file.path, imagematualizada)
        res.status(200).json(postcriado);
    } catch(erro){
        console.error(erro.message);
        res.status(500).json({"Erro":"Estamos Resolvendo mais Rapido possivel"})

    }

}

export async function altulizarnovopost(req, res){
    const id = req.params.id;
    const urlimagem = 'http://localhost:2004/${id}.gif'
    
    
    
    try {
        const imageBuffer = fs.readFileSync('uploads/${id}.gif')
        const descrisao = await gerarDescricaoComGeminif(imageBuffer)
        
        
        const post = {
            imgUrl: urlimagem,
            descrisao: descrisao,
            alt:req.body.alt
        }


        const postcriado = await altulizarpost(id, post);
        res.status(200),json(postcriado);

        }catch (erro){
        console.erro(erro.message);
        res.status(500).json({"Erro":"estamos resovendo mais rapido possivel"})
    }
}