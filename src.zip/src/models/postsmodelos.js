import conectarAoBanco from "../config/dbconfig.js"
import { ObjectId } from "mongodb";


const conexao = await conectarAoBanco(process.env.STRING_CONEXAO);

export async function getTodosPosts() {
    const db = conexao.db("teste");
    const colecao = db.collection("posts");
    return colecao.find().toArray();
    
}

export  async function criarpost(novopost){
    const db = conexao.db("teste");
    const colecao = db.collection("posts");
    return colecao.insertOne(novopost)

}


export  async function altulizarpost(id, novopost){
    const db = conexao.db("teste");
    const colecao = db.collection("posts");
    const objID = ObjectId.createFromHexString(id)
    return colecao.updateOne({_id: new ObjectId(objID)}, {$set:novopost})

}




//cert