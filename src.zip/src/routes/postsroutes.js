import express from "express";
import multer from "multer"; 
import { listarposts, postarnovopost, uploadimagem,  altulizarnovopost } from "../controller/postcontroller.js";


const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'upload/');
    },
    filename: function(req, file, cb){
        cb(null, file.originalname);
    }

})

  const upload = multer({dest:"./uploads"})

const routes = (app) => {
    app.use(express.json());
    app.get("/luiz", listarposts);
    app.post("/posts",postarnovopost)
    app.post("/upload", upload.single("imagem"), uploadimagem)

    app.put("/upload/:id",  altulizarnovopost )
}

export default routes;

